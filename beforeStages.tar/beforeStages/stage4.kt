package connectfour
/* my code without OOP type 27.11.22 by Aleksander (344673185)
// classes or structures or record or ... have to be more good way
// but, exists rule of Occam's razor
// and yet, i even don't know correctly OOP in Kotlin.
// in it stage JetBrain even don't show how to use it correctly.
// also, i don't read fully all documentation of language
// All function have to be commented for reader.
// English is not my native language, so my apologies in advance
*/

// constants
const val BOARD_DEF_VALUE = '║' // '='
const val BOARD_DEF_VALUE_LEFT = '╚' // '='
const val BOARD_DEF_VALUE_RIGHT = '╝' // '='
const val BOARD_DEF_VALUE_CENTER = '╩' // '='
const val BOARD_DEF_VALUE_BOTTOM = '═' // ═
const val BOARD_DEF_VALUE_PADCHR = ' ' // |$BOARD_DEF_VALUE_PADDING_CHAR|
const val BOARD_SIZE_PADDING = 1 // is have to be like to magic constant

const val BOARD_DEF_SIZE_ROW = 6
const val BOARD_DEF_SIZE_COLUMN = 7


// is maximal values for board range. correctly
const val BOARD_RANGE_START = 5
const val BOARD_RANGE_END = 9

// typealiases
typealias BOARD_DEF_ELEMENT_TYPE = Char
typealias boardType = MutableList<MutableList<BOARD_DEF_ELEMENT_TYPE>>

// global variables and values
var gameIsRunned = true
var boardRange = BOARD_RANGE_START..BOARD_RANGE_END
const val debugEnabled = false

// [deprecated comment] maybe is weird. need to Fix. maybe exists typedef. yet weird. so maybe in future...

// init board function. return boardType
fun initBoard(rows: Int, columns:Int):boardType {
    if (rows < 1 || columns < 1) throw Exception("Bad row/columns size")
    val ret = mutableListOf<MutableList<BOARD_DEF_ELEMENT_TYPE>>()
    repeat(rows){
        val l = mutableListOf<BOARD_DEF_ELEMENT_TYPE>()
        repeat(columns+BOARD_SIZE_PADDING){
            l.add(BOARD_DEF_VALUE) // |
            l.add(BOARD_DEF_VALUE_PADCHR) // ' ' // space
        }
        ret.add(l)
    } // is all parts that is not bottom.
    // last part of our board. is bottom part.
    val l = mutableListOf<BOARD_DEF_ELEMENT_TYPE>()
    for (ind in 1..columns+BOARD_SIZE_PADDING){
        when(ind){
            1 -> l.add(BOARD_DEF_VALUE_LEFT)
            (columns+BOARD_SIZE_PADDING) -> l.add(BOARD_DEF_VALUE_RIGHT)
            else -> {l.add(BOARD_DEF_VALUE_CENTER)} /*if(ind%2 == 0) l.add('╩') else l.add('═')*/
        }
    }
    ret.add(l)
    return ret
}

// is so so broken small function, but is works.
/*inline*/ fun getSizeBoard(board: boardType) : Pair<Int,Int> {
    val x = board.first().size-BOARD_SIZE_PADDING
    val y = board.size-BOARD_SIZE_PADDING
    return Pair(x/2,y)
}

// get index for set a turn of player
/*inline*/ fun boardRawColumnToColumn(column : Int) : Int{
    return column*2-BOARD_SIZE_PADDING // maybe uint
}

// if the column is not full or if is not full return with index
// if false then column is full
fun boardColumnIsFree(board: boardType, column:Int) : Pair<Boolean,Int>{
    for (boardRowIndex in 1 until board.reversed().size step 1){
        if(board.reversed()[boardRowIndex][boardRawColumnToColumn(column)]==BOARD_DEF_VALUE_PADCHR){
            return Pair(true,boardRowIndex)
        }
    }
    return Pair(false,0)
}
fun boardColumnIsFull(board: boardType, column : Int ) : Boolean {
    val (isFree, _) = boardColumnIsFree(board, column)
    return !isFree
}

// add charToBoardInColumn.
fun addCharToBoard(board:boardType, column:Int, ch: Char) : boardType {
    val reversedBoard = board.reversed().toMutableList()
    val maxColumn =
            board.first().size/2-BOARD_SIZE_PADDING; // so so weird. fix it future.
    if (column > maxColumn) throw Exception("outsize")
    val (isFree, b) = boardColumnIsFree(board, column)
    if( isFree ){
        reversedBoard[b][boardRawColumnToColumn(column)]=ch
    }else throw Exception("Column $column is full")
    return reversedBoard.reversed().toMutableList()
}


// it is a little deprecated, but correctly  print board
fun printBoard(board: boardType){
    //println()

    //var c:Int = 1;
    //println("Board:")
    try {
        for( i in 1 /*until*/ .. board.first().size/2-BOARD_SIZE_PADDING ){
            print(" $i")
        }
        println()
        for(l in board){
            //print(c.toString()+" ") // left part of number
            if(l != board.last())
                println(l.joinToString(""))
            else
                println(l.joinToString(BOARD_DEF_VALUE_BOTTOM.toString()))
            //c++;
        }
        println()
    } catch (exc: Exception){
        println(exc.toString().split(": ")[1])
    }
}

// init players with their names
fun initPlayers() :Pair<String,String> {
    println("Connect Four")
    println("First player's name:")
    val firstPlayerName = readln()
    println("Second player's name:")
    val secondPlayerName = readln()
    return Pair<String,String>(firstPlayerName, secondPlayerName)
}

// initialization of board
fun initBoard() :boardType {
    // see it regex on the website NxN or N X N or just NOTHING where N is numeric
    val boardRegex = Regex("^(([0-9])+( ?|\\t?)*(x|X)( ?|\\t?)*([0-9])+)?\$") // https://regex101.com/
    var tmp: String // temporarily string

    while(true){
        println("Set the board dimensions (Rows x Columns)")
        println("Press Enter for default ($BOARD_DEF_SIZE_ROW x $BOARD_DEF_SIZE_COLUMN)")
        tmp = readln().trim()
        if (boardRegex.matches(tmp)) break
        println("Invalid input")
    }
    if (tmp == "") return initBoard(BOARD_DEF_SIZE_ROW, BOARD_DEF_SIZE_COLUMN) // init default size board

    // get left and right part of our string, with numbers
    var splinted : List<String> = listOf<String>();

    // [deprecated comment] when?
    if ('x' in tmp) {
        splinted = tmp.split('x')
    }else if('X' in tmp) { // TODO: maybe 'x'.toUpperCase() 'x'.uppercase()? maybe. just constant?
        splinted = tmp.split("X")
    }
    //val splitted = tmp.split('x')

    // if count of numbers is not 2
    if ( splinted.size != 2 ) throw Exception("regex is broken in initBoard")

    val x = splinted[0].trim().toIntOrNull()?:0
    val y = splinted[1].trim().toIntOrNull()?:0
    if (!(x in boardRange)){
        println("Board rows should be from $BOARD_RANGE_START to $BOARD_RANGE_END") // maybe throw but not needable
        return initBoard()
    }
    if(!(y in boardRange)){ // if boards columns is out
        println("Board columns should be from $BOARD_RANGE_START to $BOARD_RANGE_END")
        return initBoard() // is overloading who is not know
    }
    return initBoard(x,y)
}

// action of some player on board. ch default value is 'o'
// Unit is like to void is some languages
fun boardAction(board:boardType, playerName: String, maxColumn : Int, ch: Char = 'o') : Unit {
    // there is while true because we don't want stack overflow
    while(gameIsRunned) {
        println("$playerName's turn:")
        val playerActionRaw = readln()
        val playerAction = playerActionRaw.toIntOrNull()?:-1 // if is null then is -1
        if (playerAction == -1){
            if(playerActionRaw == "end"){
                gameIsRunned = false
                break;
            }// weird
            println("Incorrect column number")
            continue;
        }else if (playerAction > maxColumn || playerAction == 0){
            println("The column number is out of range (1 - $maxColumn)")
            continue;
        }
        try {
            addCharToBoard(board, playerAction, ch)
            break
        } catch (exc: Exception){
            println(exc.toString().split(": ")[1] )
        }
    }
    if (gameIsRunned && boardCheckToCharacterRepetition(board, ch)){
        gameIsRunned = false
        printBoard(board)
        println("Player $playerName won")
    }
    if ( gameIsRunned && boardIsAllColumsFull(board) ){
        gameIsRunned = false
        printBoard(board)
        println("It is a draw")
    }



}

// print message if debug is enabled
fun printDebugMessage( msg : String ) {
    if (debugEnabled) println("DEBUG: $msg")
}

fun boardIsAllColumsFull(board:boardType) : Boolean {
    for( column in 1 until board.first().size/2-BOARD_SIZE_PADDING ){ // so so weird. fix it future
        if( boardColumnIsFull(board, column) == true ) continue // we can to check to last character just?
        else return false
    }
    return true
}


// is very weird function. but is work.
// is very weird function. but is work.
// is very weird function. but is work.
// is very weird function. but is work.
// is very weird function. but is work. ?!?

fun boardCheckOnTop( board:boardType, ch: Char, needCount: Int = 4) : Boolean{
    val reversedBoard = board.reversed().toMutableList()
    var found = false
    LoopColumnIndex@for( boardIndexColumn in 1 until
            reversedBoard.first().size ) {
        //printDebugMessage("LoopColumnIndex")
        LoopRowIndex@for( boardIndexRaw in 1 until reversedBoard.size) { // 0 is bottom part.
            //printDebugMessage("$boardIndexRaw ($boardIndexColumn) ${boardRawColumnToColumn(boardIndexColumn)}")
            //printDebugMessage( reversedBoard[boardIndexRaw][boardRawColumnToColumn(boardIndexColumn)] )
            if(reversedBoard[boardIndexRaw][boardRawColumnToColumn(boardIndexColumn)]  == ch) { // 1. found character
                printDebugMessage("Found character. now loop")
                //
                LoopCheckToStrTop@for( i in 0 until needCount ) {
                    val nextIndexRaw = if (boardIndexRaw+i >= reversedBoard.size) -1 else boardIndexRaw+i
                    val nextIndexColumnRaw = if(boardIndexColumn+i >= reversedBoard.first().size ) -1 else boardIndexColumn+i

                    val nextIndexColumn = boardRawColumnToColumn(nextIndexColumnRaw)
                    val currentIndexColumn = boardRawColumnToColumn(boardIndexColumn)

                    printDebugMessage("(currentIndexColumn:boardIndexRaw) $boardIndexColumn:$boardIndexRaw")
                    printDebugMessage("(NEXTINDEX:NEXTCOLUMN) $nextIndexRaw:$nextIndexColumn")

                    if((nextIndexRaw>0 && reversedBoard[nextIndexRaw][currentIndexColumn] == ch)) {
                        printDebugMessage("$boardIndexColumn+$i = $ch")
                        found = true
                    }
                    else{
                        printDebugMessage("$boardIndexColumn+$i != $ch; break")
                        found = false
                        break
                    }
                }
                if (found) return true
            }
        }
    }
    return found
}

fun boardCheckOnLeftRight( board:boardType, ch: Char, needCount: Int = 4) : Boolean {
    val reversedBoard = board.reversed().toMutableList()
    var found = false
    LoopColumnIndex@for( boardIndexColumn in 1 until
            reversedBoard.first().size ) {
        //printDebugMessage("LoopColumnIndex")
        LoopRowIndex@for( boardIndexRaw in 1 until reversedBoard.size) { // 0 is bottom part.
            //printDebugMessage("$boardIndexRaw ($boardIndexColumn) ${boardRawColumnToColumn(boardIndexColumn)}")
            //printDebugMessage( reversedBoard[boardIndexRaw][boardRawColumnToColumn(boardIndexColumn)] )
            if(reversedBoard[boardIndexRaw][boardRawColumnToColumn(boardIndexColumn)]  == ch) { // 1. found character
                printDebugMessage("Found character. now loop")
                //
                LoopCheckToStrTop@for( i in 0 until needCount ) {
                    val nextIndexRaw = if (boardIndexRaw+i >= reversedBoard.size) -1 else boardIndexRaw+i
                    val nextIndexColumnRaw = if(boardIndexColumn+i >= reversedBoard.first().size ) -1 else boardIndexColumn+i

                    val nextIndexColumn = boardRawColumnToColumn(nextIndexColumnRaw)
                    val currentIndexColumn = boardRawColumnToColumn(boardIndexColumn)

                    printDebugMessage("(currentIndexColumn:boardIndexRaw) $boardIndexColumn:$boardIndexRaw")
                    printDebugMessage("(NEXTINDEX:NEXTCOLUMN) $nextIndexRaw:$nextIndexColumn")

                    if( (nextIndexColumn>0 && reversedBoard[boardIndexRaw][nextIndexColumn] == ch ) ) {
                        printDebugMessage("$boardIndexColumn+$i = $ch")
                        found = true
                    }
                    else{
                        printDebugMessage("$boardIndexColumn+$i != $ch; break")
                        found = false
                        break
                    }
                }
                if (found) return true
            }
        }
    }
    return found
}

fun boardCheckOnRightTop( board:boardType, ch: Char, needCount: Int = 4) : Boolean {
    val reversedBoard = board.reversed().toMutableList()
    var found = false
    LoopColumnIndex@for( boardIndexColumn in 1 until
            reversedBoard.first().size ) {
        //printDebugMessage("LoopColumnIndex")
        LoopRowIndex@for( boardIndexRaw in 1 until reversedBoard.size) { // 0 is bottom part.
            //printDebugMessage("$boardIndexRaw ($boardIndexColumn) ${boardRawColumnToColumn(boardIndexColumn)}")
            //printDebugMessage( reversedBoard[boardIndexRaw][boardRawColumnToColumn(boardIndexColumn)] )
            if(reversedBoard[boardIndexRaw][boardRawColumnToColumn(boardIndexColumn)]  == ch) { // 1. found character
                printDebugMessage("Found character. now loop")
                //
                LoopCheckToStrTop@for( i in 0 until needCount ) {
                    val nextIndexRaw = if (boardIndexRaw+i >= reversedBoard.size) -1 else boardIndexRaw+i
                    val nextIndexColumnRaw = if(boardIndexColumn+i >= reversedBoard.first().size ) -1 else boardIndexColumn+i

                    val nextIndexColumn = boardRawColumnToColumn(nextIndexColumnRaw)
                    val currentIndexColumn = boardRawColumnToColumn(boardIndexColumn)

                    printDebugMessage("(currentIndexColumn:boardIndexRaw) $boardIndexColumn:$boardIndexRaw")
                    printDebugMessage("(NEXTINDEX:NEXTCOLUMN) $nextIndexRaw:$nextIndexColumn")

                    if( (nextIndexRaw>0&&nextIndexColumn>0&&reversedBoard[nextIndexRaw][nextIndexColumn] == ch ) ) {
                        printDebugMessage("$boardIndexColumn+$i = $ch")
                        found = true
                    }
                    else{
                        printDebugMessage("$boardIndexColumn+$i != $ch; break")
                        found = false
                        break
                    }
                }
                if (found) return true
            }
        }
    }
    return found
}

fun boardCheckOnLeftBottom( board:boardType, ch: Char, needCount: Int = 4) : Boolean {
    val reversedBoard = board.reversed().toMutableList()
    var found = false
    LoopColumnIndex@for( boardIndexColumn in 1 until
            reversedBoard.first().size ) {
        //printDebugMessage("LoopColumnIndex")
        LoopRowIndex@for( boardIndexRaw in 1 until reversedBoard.size) { // 0 is bottom part.
            //printDebugMessage("$boardIndexRaw ($boardIndexColumn) ${boardRawColumnToColumn(boardIndexColumn)}")
            //printDebugMessage( reversedBoard[boardIndexRaw][boardRawColumnToColumn(boardIndexColumn)] )
            if(reversedBoard[boardIndexRaw][boardRawColumnToColumn(boardIndexColumn)]  == ch) { // 1. found character
                printDebugMessage("Found character. now loop")
                //
                LoopCheckToStrTop@for( i in 0 until needCount ) {
                    val nextIndexRaw = if (boardIndexRaw-i < 0 ) -1 else boardIndexRaw-i
                    val nextIndexColumnRaw = if(boardIndexColumn+i >= reversedBoard.first().size ) -1 else boardIndexColumn+i

                    val nextIndexColumn = boardRawColumnToColumn(nextIndexColumnRaw)
                    val currentIndexColumn = boardRawColumnToColumn(boardIndexColumn)

                    printDebugMessage("(currentIndexColumn:boardIndexRaw) $boardIndexColumn:$boardIndexRaw")
                    printDebugMessage("(NEXTINDEX:NEXTCOLUMN) $nextIndexRaw:$nextIndexColumn")

                    if( (nextIndexRaw>0&&nextIndexColumn>0&&reversedBoard[nextIndexRaw][nextIndexColumn] == ch ) ) {
                        printDebugMessage("$boardIndexColumn+$i = $ch")
                        found = true
                    }
                    else{
                        printDebugMessage("$boardIndexColumn+$i != $ch; break")
                        found = false
                        break
                    }
                }
                if (found) return true
            }
        }
    }
    return found
}



fun boardCheckToCharacterRepetition( board: boardType, ch: Char, needCount : Int = 4 ) : Boolean {
	if (boardCheckOnTop(board, ch, needCount)) {
		printDebugMessage("Board found in top value")
		return true
	} 
	if (boardCheckOnLeftRight(board, ch, needCount)) {
		printDebugMessage("Board found in top value")
		return true
	} 
	if (boardCheckOnRightTop(board, ch, needCount)) {
		printDebugMessage("Board found in top value")
		return true
	} 
	if (boardCheckOnLeftBottom(board, ch, needCount)) {
		printDebugMessage("Board found in top value")
		return true
	} 

	return false
}

// main funciton
fun main(){
    val (fPlayer, sPlayer) = initPlayers() // first player and second player
    val myBoard = initBoard()
    val (x,y) = getSizeBoard(myBoard) // TODO("fix it some laters")
    println("$fPlayer VS $sPlayer")
    println("$y X $x board")

    while(gameIsRunned) {
        if (gameIsRunned) printBoard(myBoard)
        boardAction(myBoard, fPlayer, x)

        if (gameIsRunned) printBoard(myBoard)
        boardAction(myBoard, sPlayer, x, '*')
    }
    println("Game over!")


}
