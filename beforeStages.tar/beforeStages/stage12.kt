package connectfour

//classes or structures or record or ... have to be more good way

const val BOARD_DEF_VALUE = '║' // '='
const val BOARD_DEF_VALUE_LEFT = '╚' // '='
const val BOARD_DEF_VALUE_RIGHT = '╝' // '='
const val BOARD_DEF_VALUE_CENTER = '╩' // '='
const val BOARD_DEF_VALUE_BOTTOM = '═' // ═
const val BOARD_DEF_VALUE_PADCHR = ' '
const val BOARD_SIZE_PADDING = 1

const val BOARD_DEF_SIZE_ROW = 6 //Pair(6,7)
const val BOARD_DEF_SIZE_COLUMN = 7
const val BOARD_RANGE_START = 5
const val BOARD_RANGE_END = 9
var boardRange = BOARD_RANGE_START..BOARD_RANGE_END

typealias BOARD_DEF_ELEMENT_TYPE = Char
typealias boardType = MutableList<MutableList<BOARD_DEF_ELEMENT_TYPE>>


// maybe is weird. need to Fix. maybe exists typedef. yet weird. so maybe in future...

fun initBoard(rows: Int, columns:Int):boardType {
    if (rows < 1 || columns < 1) throw Exception("Bad row/columns size")
    var ret = mutableListOf<MutableList<BOARD_DEF_ELEMENT_TYPE>>()
    repeat(rows){
        val l = mutableListOf<BOARD_DEF_ELEMENT_TYPE>()
        repeat(columns+BOARD_SIZE_PADDING){
            l.add(BOARD_DEF_VALUE)
            l.add(BOARD_DEF_VALUE_PADCHR)
        }
        ret.add(l)
    }
    //
    val l = mutableListOf<BOARD_DEF_ELEMENT_TYPE>()
    for (ind in 1..columns+BOARD_SIZE_PADDING){
        when(ind){
            1 -> l.add(BOARD_DEF_VALUE_LEFT)
            (columns+BOARD_SIZE_PADDING) -> l.add(BOARD_DEF_VALUE_RIGHT)
            else -> {l.add(BOARD_DEF_VALUE_CENTER)} /*if(ind%2 == 0) l.add('╩') else l.add('═')*/
        }
    }
    ret.add(l)
    return ret;
}

/*inline*/ fun getSizeBoar(board: boardType) : Pair<Int,Int> {
    val x = board.first().size-1
    val y = board.size-1
    return Pair(x,y)
}

fun printBoard(board: boardType){
    //println()

    //var c:Int = 1;
    //println("Board:")
    try {
        for( i in 1 /*until*/ .. board.first().size/2-BOARD_SIZE_PADDING ){
            print(" $i")
        }
        println()
        for(l in board){
            //print(c.toString()+" ") // left part of number
            if(l != board.last())
                println(l.joinToString(""))
            else
                println(l.joinToString(BOARD_DEF_VALUE_BOTTOM.toString()))
            //c++;
        }
        println()
    } catch (exc: Exception){
        println(exc.toString().split(": ")[1])
    }
}

fun initPlayers() :Pair<String,String> {
    println("Connect Four")
    println("First player's name:")
    val firstPlayerName = readln()
    println("Second player's name:")
    val secondPlayerName = readln()
    return Pair<String,String>(firstPlayerName, secondPlayerName)
}

fun initBoard() :boardType {

    val boardRegex = Regex("^(([0-9])+( ?|\\t?)*(x|X)( ?|\\t?)*([0-9])+)?\$") // https://regex101.com/
    var tmp: String

    while(true){
        println("Set the board dimensions (Rows x Columns)")
        println("Press Enter for default ($BOARD_DEF_SIZE_ROW x $BOARD_DEF_SIZE_COLUMN)")
        tmp = readln().trim()
        if (boardRegex.matches(tmp)) break
        println("Invalid input")
    }
    if (tmp == "") return initBoard(BOARD_DEF_SIZE_ROW, BOARD_DEF_SIZE_COLUMN)
    var splinted : List<String> = listOf<String>();
    //when?
    if ('x' in tmp) {
        splinted = tmp.split('x')
    }else if('X' in tmp) { // TODO: maybe 'x'.toUpperCase() 'x'.uppercase()? maybe. just constant?
        splinted = tmp.split("X")
    }
    //val splitted = tmp.split('x')

    if ( splinted.size != 2 ) throw Exception("regex is broken in initBoard")

    val x = splinted[0].trim().toIntOrNull()?:0
    val y = splinted[1].trim().toIntOrNull()?:0
    if (!(x in boardRange)){
        println("Board rows should be from $BOARD_RANGE_START to $BOARD_RANGE_END") // maybe throw but not needable
        return initBoard()
    }
    if(!(y in boardRange)){
        println("Board columns should be from $BOARD_RANGE_START to $BOARD_RANGE_END")
        return initBoard()
    }
    return initBoard(x,y)
}

fun main(){
    val (fPlayer, sPlayer) = initPlayers() // first player and second player
    val myBoard = initBoard()
    val (x,y) = getSizeBoar(myBoard) // TODO("fix it some laters")
    println("$fPlayer VS $sPlayer")
    println("$y X $x board")
    printBoard(myBoard)

}
